from odoo import api, fields, models, _
from odoo.exceptions import ValidationError
class EmployeeIncident(models.Model):
    _name = "employee.incident"
    _description = "Employee Incident "

    involved = fields.Selection([
        ('employee', 'Employee'),
        ('patient', 'Patient'),
        ('others', 'Others'),
    ], string='Involved', copy=False, index=True, tracking=True)

    name = fields.Char(string='Name')
    incident_id = fields.Char(string='ID', copy=False, readonly=True )
    contact = fields.Char(string='Contact')
    age = fields.Integer(string="Age")
    gender = fields.Selection([('male', 'Male'), ('female', 'Female')], string='Gender')
    designation = fields.Char(string='Designation')
    inc_department = fields.Char(string='INC Department')

    # date_time = fields.Datetime(string="Date_Time", default=fields.Datetime.now)
    date = fields.Date(string="Date")
    time = fields.Datetime(string="Time", default=fields.Datetime.now)

    eye_witness_name = fields.Char(string='Eye Witness Name')
    contact_no = fields.Char(string='Contact No')
    place = fields.Char(string='Place of Event:')

    title_of_incident = fields.Char(string="Title of Incident")
    description = fields.Char(string="Incident Description")
    injury_illness = fields.Selection([('yes', 'Yes'), ('no', 'No')], string='Injury/illness')
    treatment_given = fields.Selection([('yes', 'Yes'), ('no', 'No')], string='Treatment Given')

    type = fields.Char(string="Type of injury/illness")

    by_whom = fields.Char(string='By Whom:')
    where = fields.Char(string='Where:')
    description_ = fields.Char(string="Description")
    status = fields.Selection([
        ('pending', 'Pending'),
        ('accepted', 'Accepted'),
        ('on_process', 'On_Process'),
    ], string='Status', copy=False, index=True, tracking=True)

    image = fields.Binary(string="Image")

    #this field is not required
    id = fields.Integer(string="Incident ID")
    @api.model
    def create(self, vals):
        if vals.get('incident_id', _('New')) == _('New'):
            vals['incident_id'] = self.env['ir.sequence'].next_by_code('employee.incident.sequence') or _('New')
        return super(EmployeeIncident, self).create(vals)

    def send_to_quality_admin(self):
        # Process your data or create a record directly
        quality_admin_obj = self.env['quality.admin'].create({
            'id': self.id,
            'name': self.name,
            'eye_witness_name': self.eye_witness_name,
            'title_of_incident': self.title_of_incident,
            'description': self.description,
            'incident_id': self.incident_id,
            'involved': self.involved,
            'place': self.place,
            'date': self.date,
            'inc_department': self.inc_department,
        })

        # Additional logic or return statement if needed
        return {
            'name': 'Send to Quality Admin',
            'view_mode': 'form',
            'res_model': 'quality.admin',
            'res_id': quality_admin_obj.id,
            'type': 'ir.actions.act_window',
            'target': 'new',
        }


