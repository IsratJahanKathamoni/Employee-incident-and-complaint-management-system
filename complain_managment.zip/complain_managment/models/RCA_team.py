from odoo import api, fields, models, _
from odoo.exceptions import ValidationError
import base64

class RCATeam(models.Model):
    _name = "rca.team"
    _description = "RCA Team"

    involved = fields.Char(string='Involved', readonly=True)
    incident_code = fields.Char(string="Incident Code:", readonly=True)
    meeting_date_time = fields.Datetime(string="Meeting_Date and Time")

    eye_witness_name = fields.Char(string='Eye Witness Name', readonly=True)
    title_of_incident = fields.Char(string="Title of Incident", readonly=True)
    description = fields.Char(string="Incident Description", readonly=True)
    place = fields.Char(string='Place of Event:', readonly=True)
    incident_id = fields.Char(string="Incident ID", readonly=True)
    name = fields.Char(string='Name', readonly=True)
    date = fields.Date(string="Date of Incident", readonly=True)

    evidence = fields.Binary(string="Upload Evidence")

    emp_assign = fields.Char(string="Assigned Employee:", readonly=True)
    email = fields.Char(string="Email:", readonly=True)

    emp_id = fields.Char(string='EMP_ID', compute='_compute_emp_id', readonly=True)

    emp_assign_inc = fields.Many2one('employee.list',  string="Assign Employee")

    mail = fields.Char(string="Employee Email", compute='_compute_email', readonly=True)
    department = fields.Char(string='Department:', compute='_compute_employee_department', readonly=True)
    inc_department = fields.Char(string='Inc Department:', readonly=True)

    impact = fields.Char(string="Impact for risk Calculation:", readonly=True)
    doctor_feedback = fields.Char(string="Feedback:", readonly=True)

    @api.depends('emp_assign_inc')
    def _compute_email(self):
        for record in self:
            record.mail = record.emp_assign_inc.mail if record.emp_assign_inc else False

    @api.depends('emp_assign_inc')
    def _compute_emp_id(self):
        for record in self:
            record.emp_id = record.emp_assign_inc.emp_id if record.emp_assign_inc else False

    @api.depends('emp_assign_inc')
    def _compute_employee_department(self):
        for record in self:
            record.department = record.emp_assign_inc.department if record.emp_assign_inc else False

    def send_to_employee(self):
        # Process  data or create a record directly
        employee_task_obj = self.env['employee.task'].create({

            'incident_code': self.incident_code,
            'involved': self.involved,

            'title_of_incident': self.title_of_incident,
            'description': self.description,

            'emp_assign_inc': self.emp_assign_inc.name,
            'emp_id': self.emp_id,
            'place': self.place,
            'evidence': base64.b64encode(self.evidence) if self.evidence else False,
            'impact': self.impact,
            'doctor_feedback': self.doctor_feedback,
        })
        # Additional logic or return statement if needed
        return {
            'name': 'Send to Employee',
            'view_mode': 'form',
            'res_model': 'rca.team',
            'res_id': employee_task_obj.id,
            'type': 'ir.actions.act_window',

            #button e click korar poreer form view

            'view_id': self.env.ref('complain_managment.view_employee_task_form_custom').id,
            'target': 'new',
        }

