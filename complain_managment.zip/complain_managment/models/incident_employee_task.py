from odoo import api, fields, models, _
from odoo.exceptions import ValidationError
import base64

class EmployeeTask(models.Model):
    _name = "employee.task"
    _description = "Employee task "

    emp_assign_inc = fields.Char(string="Assigned Employee:", readonly=True)
    emp_id = fields.Char(string='EMP_ID', readonly=True)
    title_of_incident = fields.Char(string="Title of Incident", readonly=True)
    description = fields.Char(string="Incident Description", readonly=True)
    place = fields.Char(string='Place of Event:', readonly=True)
    involved = fields.Char(string='Involved', readonly=True)
    incident_code = fields.Char(string="Incident Code:", readonly=True)

    task_status = fields.Selection([
        ('done', 'DONE'),
        ('on_processing', 'On_Processing'),
    ], string='Task Status:', copy=False, index=True, tracking=True)

    report = fields.Binary(string="Upload Incident Report:")
    evidence = fields.Binary(string="Upload Evidence", readonly=True)


    impact = fields.Char(string="Impact for risk Calculation:", readonly=True)
    doctor_feedback = fields.Char(string="Feedback:", readonly=True)

    def send_to_role_manager(self):
        # Process  data or create a record directly
        role_manager_obj = self.env['role.manager'].create({

            'incident_code': self.incident_code,
            'emp_assign_inc': self.emp_assign_inc,
            'emp_id': self.emp_id,
            'task_status': self.task_status,
            'report': base64.b64encode(self.report) if self.report else False,

        })

        # Additional logic or return statement if needed
        return {
            'name': 'Send to role manager',
            'view_mode': 'form',
            'res_model': 'employee.task',
            'res_id': role_manager_obj.id,
            'type': 'ir.actions.act_window',
            # button e click korar poreer form view
            # 'view_id': self.env.ref('complain_managment.view_employee_task_form_custom').id,
            'target': 'new',
        }
