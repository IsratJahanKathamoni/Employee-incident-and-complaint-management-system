from odoo import api, fields, models, _
from odoo.exceptions import ValidationError

class QualityAdmin(models.Model):
    _name = "quality.admin"
    _description = "Quality Admin"

    incident_id = fields.Char(string="Incident ID", readonly=True)
    name = fields.Char(string='Name', readonly=True)
    eye_witness_name = fields.Char(string='Eye Witness Name', readonly=True)
    title_of_incident = fields.Char(string="Title of Incident", readonly=True)
    description = fields.Char(string="Incident Description", readonly=True)

    incident_code = fields.Char(string="Incident Code:", readonly=True)
    meeting_date_time = fields.Datetime(string="Meeting_Date and Time")
    place = fields.Char(string='Place of Event:', readonly=True)

    involved = fields.Selection([
        ('employee', 'Employee'),
        ('patient', 'Patient'),
        ('others', 'Others'),
    ], string='Involved', copy=False, index=True, tracking=True, readonly=True)
    title_of_event = fields.Char(string="Title of Event")
    feedback = fields.Char(string="Feedback:")
    meeting_point = fields.Integer(string="Meeting_Point")
    emp_assign = fields.Many2one('employee.list', string="Assign Employee")
    email = fields.Char(string="Employee Email", compute='_compute_employee_email', store=True)
    inc_department = fields.Char(string='Inc Department:', readonly=True)
    date = fields.Date(string="Date of Incident", readonly=True)
    status = fields.Selection([
        ('pending', 'Pending'),
        ('accepted', 'Accepted'),
        ('on_process', 'On_Process'),
    ], string='Status', copy=False, index=True, tracking=True, default='pending')

    @api.model
    def create(self, vals):
        if vals.get('incident_code', _('New')) == _('New'):
            vals['incident_code'] = self.env['ir.sequence'].next_by_code('incident.code.sequence') or _('New')
        return super(QualityAdmin, self).create(vals)

    @api.depends('emp_assign')
    def _compute_employee_email(self):
        for record in self:
            record.email = record.emp_assign.mail if record.emp_assign else False

    def send_to_qa_team(self):
        # Process your data or create a record directly
        qa_team_obj = self.env['qa.team'].create({
            'feedback': self.feedback,
            'incident_code': self.incident_code,
            'meeting_date_time': self.meeting_date_time,
            'eye_witness_name': self.eye_witness_name,
            'title_of_incident': self.title_of_incident,  # Corrected field name
            'description': self.description,
            'emp_assign': self.emp_assign.name,
            'email': self.email,
            'incident_id': self.incident_id,

        })

        # Additional logic or return statement if needed
        return {
            'name': 'Send to QA team',
            'view_mode': 'form',
            'res_model': 'qa.team',
            'res_id': qa_team_obj.id,
            'type': 'ir.actions.act_window',
            'view_id': self.env.ref('complain_managment.view_qa_team_form_custom').id,
            'target': 'new',
        }

    def send_to_rca_team(self):
        # Process  data or create a record directly
        rca_team_obj = self.env['rca.team'].create({

            'incident_code': self.incident_code,
            'involved': self.involved,
            'incident_id': self.incident_id,
            'name': self.name,
            'inc_department': self.inc_department,
            'title_of_incident': self.title_of_incident,
            'description': self.description,
            'date': self.date,
            'emp_assign': self.emp_assign.name,
            'email': self.email,
            'place': self.place,
        })

        # Additional logic or return statement if needed
        return {
            'name': 'Send to RCA team',
            'view_mode': 'form',
            'res_model': 'rca.team',
            'res_id': rca_team_obj.id,
            'type': 'ir.actions.act_window',
            'view_id': self.env.ref('complain_managment.view_rca_team_form_custom').id,
            'target': 'new',
        }
    @api.onchange('status')
    def _onchange_status(self):
        if self.incident_id:
            incident = self.env['employee.incident'].search([('incident_id', '=', self.incident_id)])
            if incident:
                incident.status = self.status
