
from odoo import api, fields, models, _
from odoo.exceptions import ValidationError

class QATeam(models.Model):
    _name = "qa.team"
    _description = "Quality Team"

    image_f = fields.Binary(string=" ")
    image_i = fields.Binary(string=" ")

    incident_id = fields.Char(string="Incident ID", readonly=True)
    eye_witness_name = fields.Char(string='Eye Witness Name', readonly=True)
    title_of_incident = fields.Char(string="Title of Incident", readonly=True)
    description = fields.Char(string="Incident Description", readonly=True)

    incident_code = fields.Char(string="Incident Code:", readonly=True)
    meeting_date_time = fields.Datetime(string="Meeting_Date and Time", readonly=True)

    date = fields.Date(string="Date",readonly=True)
    place = fields.Char(string='Place of Event:', readonly=True)
    title_of_event = fields.Char(string="Title of Event", readonly=True)
    feedback = fields.Char(string="Feedback From Quality Admin:", readonly=True)
    meeting_point = fields.Integer(string="Meeting_Point", readonly=True)

    category = fields.Selection([
        ('clinical', 'CLINICAL'),
        ('non clinical', 'NON CLINICAL'),
    ], string='General Category', copy=False, index=True, tracking=True)

    event_type = fields.Selection([
        ('near_miss', 'NEAR MISS'),
        ('sentinel', 'SENTINEL'),
        ('error', 'ERROR'),
        ('variance', 'VARIANCE'),
        ('adverse_event', 'ADVERSE EVENT'),
    ], string='Type Of Event', copy=False, index=True, tracking=True)

    other_event_type = fields.Char(string='Other:SPECIFY')
    frequency = fields.Float(string="Frequency")
    Impact = fields.Float(string='Impact')
    Result = fields.Float(string='Result: Impact x Frequency', compute='_compute_result', store=True, readonly=True)
    emp_assign = fields.Char(string="Assign Employee", readonly=True)
    email = fields.Char(string="Employee Email", readonly=True)

    @api.depends('frequency','Impact')
    def _compute_result(self):
        for record in self:
            frequency = record.frequency
            impact = record.Impact
            result = frequency * impact
            record.Result = result

    def send_to_doctor_feedback(self):
        # Process your data or create a record directly
        doctor_feedback_obj = self.env['doctor.feedback'].create({
            'incident_id': self.incident_id,
            'incident_code': self.incident_code,
            'title_of_incident': self.title_of_incident,
            'description': self.description,
            'Result': self.Result,
            'category': self.category,
            'feedback': self.feedback,
            'emp_assign': self.emp_assign.name,
            'date': self. date,
            'place': self.place,
        })

        return {
            'name': 'Send to doctor feedback',
            'view_mode': 'form',
            'res_model': 'doctor.feedback',
            'res_id': doctor_feedback_obj.id,
            'type': 'ir.actions.act_window',
            'target': 'new',
        }
