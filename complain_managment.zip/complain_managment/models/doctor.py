from odoo import api, fields, models, _
from odoo.exceptions import ValidationError

class DoctorFeedback(models.Model):
    _name = "doctor.feedback"
    _description = "Doctor Feedback "

    involved = fields.Char(string='Involved', readonly=True)
    incident_code = fields.Char(string="Incident Code:", readonly=True)
    incident_id = fields.Char(string="Incident ID", readonly=True)
    feedback = fields.Char(string="Quality Admin's Feedback:", readonly="True")

    date = fields.Date(string="Date of Incident", readonly=True)
    place = fields.Char(string='Place of Event:', readonly=True)
    emp_assign = fields.Char(string="Assigned Employee:", readonly=True)
    email = fields.Char(string="Email:", readonly=True)
    title_of_event = fields.Char(string="Title of Event", readonly="True")
    title_of_incident = fields.Char(string="Title of Incident", readonly=True)
    description = fields.Char(string="Incident Description", readonly="True")
    category = fields.Selection([
        ('clinical', 'CLINICAL'),
        ('non clinical', 'NON CLINICAL'),

    ], string='General Category', copy=False, index=True, tracking=True, readonly="True")
    Result = fields.Char(string='Risk measure:Impact x Frequency', readonly="True")

    impact = fields.Char(string="Impact for risk Calculation:")
    doctor_feedback = fields.Char(string="Feedback:")

    def send_to_rca(self):
        # Process  data or create a record directly
        rca_team_obj = self.env['rca.team'].create({

            'incident_code': self.incident_code,
            'involved': self.involved,
            'incident_id': self.incident_id,
            'title_of_incident': self.title_of_incident,
            'description': self.description,
            'date': self.date,
            'place': self.place,
            'emp_assign': self.emp_assign,
            'email': self.email,

            'doctor_feedback': self.doctor_feedback,
            'impact': self.impact,
        })

        # Additional logic or return statement if needed
        return {
            'name': 'Send to RCA Team',
            'view_mode': 'form',
            'res_model': 'doctor.feedback',
            'res_id': rca_team_obj.id,  # <-- Use rca_team_obj.id instead of the object
            'type': 'ir.actions.act_window',
            'target': 'new',
        }
