from odoo import api, fields, models, _
from odoo.exceptions import ValidationError


class FrequencyTable(models.Model):
    _name = "frequency.table"
    _description = "Frequency Table"

    name = fields.Char(string='Name:')
    value = fields.Int(string='Value:')
    definition = fields.Char(string='Definition:')
