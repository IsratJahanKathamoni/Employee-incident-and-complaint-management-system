# -*- coding: utf-8 -*-
from odoo import api, fields, models, _
from odoo.exceptions import ValidationError
class EmployeeList(models.Model):
    _name = "employee.list"
    _description = "Employee List"

    name = fields.Char(string='Name:')
    emp_id = fields.Char(string='EMP_ID', copy=False, readonly=True )
    contact = fields.Char(string='Contact:')
    age = fields.Integer(string="Age:")
    gender = fields.Selection([('male', 'Male'), ('female', 'Female')], string='Gender:')
    designation = fields.Char(string='Designation:')
    department = fields.Char(string='Department:')
    mail= fields.Char(string='E-mail:')
    remarks= fields.Char(string='Remarks:')
    image = fields.Binary(string="Image")

    @api.model
    def create(self, vals):
        if vals.get('emp_id', _('New')) == _('New'):
            vals['emp_id'] = self.env['ir.sequence'].next_by_code('incident.employee.sequence') or _('New')
        return super(EmployeeList, self).create(vals)