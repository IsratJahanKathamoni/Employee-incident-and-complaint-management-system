from odoo import api, fields, models, _
from odoo.exceptions import ValidationError

class RCATeam(models.Model):
    _name = "role.manager"
    _description = "Role Manager"

    emp_assign_inc = fields.Char(string="Assigned Employee:", readonly=True)
    emp_id = fields.Char(string='EMP_ID', readonly=True)
    incident_code = fields.Char(string="Incident Code:", readonly=True)

    task_status = fields.Selection([
        ('done', 'DONE'),
        ('on_processing', 'On_Processing'),
    ], string='Task Status:', copy=False, index=True, tracking=True, readonly="True")

    report = fields.Binary(string="Upload Incident Report:",readonly="True")

    select_name = fields.Many2one('employee.list', string="Employee Name:")
    emp_id_ = fields.Char(string='EMP_ID', compute='_compute_employee_id', readonly=True)
    contact = fields.Char(string='Contact:', compute='_compute_employee_contact', readonly=True)
    designation = fields.Char(string='Designation:', compute='_compute_employee_designation', readonly=True)
    email = fields.Char(string="Employee Email", compute='_compute_email', readonly=True)
    group = fields.Selection([
        ('during_incident_report', 'During Incident Report'),
        ('during_rca_committee', 'During RCA Committee'),
        ('others', 'Others'),
    ], string='Group:', copy=False, index=True, tracking=True)

    status = fields.Selection([
        ('active', 'Active'),
        ('inactive', 'Inactive'),

    ], string='Status:', copy=False, index=True, tracking=True)
    remarks = fields.Char(string='Remarks:')

    @api.depends('select_name')
    def _compute_email(self):
        for record in self:
            record.email = record.select_name.mail if record.select_name else False

    @api.depends('select_name')
    def _compute_employee_designation(self):
        for record in self:
            record.designation = record.select_name.designation if record.select_name else False

    @api.depends('select_name')
    def _compute_employee_id(self):
        for record in self:
            record.emp_id_ = record.select_name.emp_id if record.select_name else False

    @api.depends('select_name')
    def _compute_employee_contact(self):
        for record in self:
            record.contact = record.select_name.contact if record.select_name else False
