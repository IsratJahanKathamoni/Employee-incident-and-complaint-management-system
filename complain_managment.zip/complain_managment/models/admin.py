from odoo import api, fields, models, _
from odoo.exceptions import ValidationError
class Admin (models.Model):
    _name = "employee.incident"
    _description = "Employee"


    id = fields.Integer(string="ID")
    name = fields.Char(string='Name')
    contact = fields.Char(string='Contact')
    age = fields.Integer(string="Age")
    gender = fields.Selection([('male', 'Male'), ('female', 'Female')], string='Gender')
    designation = fields.Char(string='Designation')
    department = fields.Char(string='Department')
