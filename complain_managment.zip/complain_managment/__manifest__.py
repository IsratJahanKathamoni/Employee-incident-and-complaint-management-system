# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
{
    'name': 'Incident and Complaint Management',
    'version': '1.0.0',
    'category': 'Complain',
    'author': 'Israt Jahan Katha Moni',
    'sequence': -100,
    'summary': 'Incident & Complaint management system',
    'description': """Complaint Management system""",
    'depends': ['sale'],
    'data': [
        'security/ir.model.access.csv',
        'security/security.xml',
        'security/sequence.xml',
        'views/menu_views.xml',
        'views/menu_incident_views.xml',
        'views/employee_complain_views.xml',
        'views/employee_incident_views.xml',
        'views/incident_quality_admin.xml',
        'views/incident_doctor.xml',
        'views/incident_QA_team.xml',
        'views/incident_employee_list.xml',
        'views/incident_RCA_views.xml',
        'views/incident_role_manager.xml',
        'views/incident_employee_task_views.xml',
        'views/button_qa_send_rca.xml',
        'views/button_qa_send_qa_team.xml',
        'views/button_rca_send_employee.xml',

    ],

    'css': [
        'static/src/css/style.css',
    ],
    'installable': True,
    'auto_install': False,

    'demo': [],
    'application': True,
    'auto_install': False,
    'assets': {},
    'license': 'GPL-3',
}
